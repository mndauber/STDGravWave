this is a readme file for PlotSTDH1L1GravWave.py
needed vars are time, tevent, strain_whitenbp
then strain_L1_whitenbp and strain_H1_whitenbp
then bb, ab, strain_H1_whiten, strain_L1_whiten, and normalization
normalization is comprised of fband and fs
bb and ab are comprised of fband and fs
strain_H1_whiten and strain_L1_whiten are comprised of strain_H1, psd_H1, and dt, strain_L1, psd_L1, and dt
psd_H1 and psd_L1 are comprised of freqs and Pxx_H1 and Pxx_L1
Pxx_H1 and Pxx_L1 and freqs are comrpised of fs and strain_L1 and strain_H1



battle plan:
create a text file that users will put file names into, the program will require sets of H1 and L1 data, with the H1 file coming first, and then the L1 data file. if there is an odd number of files in the list, aka if there is a non pair, then the file will throw an error
the program will then attempt to find each hdf5 file in the local directory that is stated in the text file, and spit out an error if it cannot be found
the program will then load and plot each hdf5 file in there, generating one line for each on the top graph, and then plotting the std of the subtraction of the h1 and l1 lines on the bottom graph.
make a method that takes in time(it doesnt matter which one(l1 or h1) you take time from cuz they are the same), fs, fband, strain_l1, and strain H1, and spits out time/time-tevent, strain_L1_whitenbp and strain_H1_whitenbp

tevent = time number in file name + 16 seconds
time is the array of time values from the data
need to calculate the number of data points that it takes for the time to increase by 1 second in the data, and that number is the frequency of the data. 


issues:
where does fband come from? fs can be extracted from the file name, and strain_L1 and strain_H1 are the data in the files, but idk how to get fband without the json file that specifies it
we are gonna hard code fband to be 43, 800 at prof gebhart's recommendation. this will hopefully include the most data and stuff.
