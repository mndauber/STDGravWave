#don't forget to include my name, Matthew Dauber, somewhere and like, date my work or something, especially if this file is gonna be distributed I'd like some credit or something :3

import os, json, h5py
from scipy import signal
from scipy.interpolate import interp1d
from scipy.signal import butter, filtfilt, iirdesign, zpk2tf, freqz
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
import readligo as rl
import fnmatch


#this code was taken and used without permission from jeremiahajohnson on github. i claim no credit for its creation, although i did make some minor edits and changed some bits to remove parameters cuz we only have seconds
#https://gist.github.com/jeremiahajohnson/eca97484db88bcf6b124    -   link to the github post where i got the code
#this method just converts gpsseconds time to the timeformat used for naming events, to provide human comprehensible labels for the graphs
def getGWName(gpsseconds):
    import datetime, calendar
    datetimeformat = "GW%y%m%d"
    leapseconds=27
    epoch = datetime.datetime.strptime("GW800106",datetimeformat)
    elapsed = datetime.timedelta(days=(0),seconds=(gpsseconds+leapseconds))
    return datetime.datetime.strftime(epoch + elapsed,datetimeformat)


#these three methods are taken from the readligo file from one of the ligo tutorials, and is used to read in the data file. I claim no credit for their creation, and am using them without permission? 
def read_frame(filename, ifo, readstrain=True, strain_chan=None, dq_chan=None, inj_chan=None):
    """
    Helper function to read frame files
    """
    try:
        import Fr
    except:
        from pylal import Fr

    if ifo is None:
        raise TypeError("""To read GWF data, ifo must be 'H1', 'H2', or 'L1'.
        def loaddata(filename, ifo=None):""")

    #-- Read strain channel
    if strain_chan is None:
        strain_chan = ifo + ':LOSC-STRAIN'
    
    if readstrain:
        try:
            sd = Fr.frgetvect(filename, strain_chan)    
            strain = sd[0]
            gpsStart = sd[1] 
            ts = sd[3][0]
        except:
            print("ERROR reading file {0} with strain channel {1}".format(filename, strain_chan))
            raise
    else:
        ts = 1
        strain = 0
    
    #-- Read DQ channel
    if dq_chan is None:
        dq_chan = ifo + ':LOSC-DQMASK'

    try:
        qd = Fr.frgetvect(filename, dq_chan)
        gpsStart = qd[1]
        qmask = np.array(qd[0])
        dq_ts = qd[3][0]
        shortnameList_wbit = qd[5].split()
        shortnameList = [name.split(':')[1] for name in shortnameList_wbit]
    except:
        print("ERROR reading DQ channel '{0}' from file: {1}".format(dq_chan, filename))
        raise

    #-- Read Injection channel
    if inj_chan is None:
        inj_chan = ifo + ':LOSC-INJMASK'
    
    try:
        injdata = Fr.frgetvect(filename, inj_chan)
        injmask = injdata[0]
        injnamelist_bit = injdata[5].split()
        injnamelist     = [name.split(':')[1] for name in injnamelist_bit]
    except:
        print("ERROR reading injection channel '{0}' from file: {1}".format(inj_chan, filename))
        raise

    return strain, gpsStart, ts, qmask, shortnameList, injmask, injnamelist
def read_hdf5(filename, readstrain=True):
    """
    Helper function to read HDF5 files
    """
    import h5py
    dataFile = h5py.File(filename, 'r')

    #-- Read the strain
    if readstrain:
        strain = dataFile['strain']['Strain'][...]
    else:
        strain = 0

    ts = dataFile['strain']['Strain'].attrs['Xspacing']
    
    #-- Read the DQ information
    dqInfo = dataFile['quality']['simple']
    qmask = dqInfo['DQmask'][...]
    shortnameArray = dqInfo['DQShortnames'].value
    shortnameList  = list(shortnameArray)
    
    # -- Read the INJ information
    injInfo = dataFile['quality/injections']
    injmask = injInfo['Injmask'][...]
    injnameArray = injInfo['InjShortnames'].value
    injnameList  = list(injnameArray)
    
    #-- Read the meta data
    meta = dataFile['meta']
    gpsStart = meta['GPSstart'].value    
    
    dataFile.close()
    return strain, gpsStart, ts, qmask, shortnameList, injmask, injnameList
def loaddata(filename, ifo=None, tvec=True, readstrain=True, strain_chan=None, dq_chan=None, inj_chan=None):
    """
    The input filename should be a LOSC .hdf5 file or a LOSC .gwf
    file.  The file type will be determined from the extenstion.  
    The detector should be H1, H2, or L1.

    The return value is: 
    STRAIN, TIME, CHANNEL_DICT

    STRAIN is a vector of strain values
    TIME is a vector of time values to match the STRAIN vector
         unless the flag tvec=False.  In that case, TIME is a
         dictionary of meta values.
    CHANNEL_DICT is a dictionary of data quality channels    
    STRAIN_CHAN is the channel name of the strain vector in GWF files.
    DQ_CHAN is the channel name of the data quality vector in GWF files.
    INJ_CHAN is the channel name of the injection vector in GWF files.
    """

    # -- Check for zero length file
    try:
        if os.stat(filename).st_size == 0:
            return None, None, None
    except:
        return None,None,None

    file_ext = os.path.splitext(filename)[1]    
    if (file_ext.upper() == '.GWF'):
        strain, gpsStart, ts, qmask, shortnameList, injmask, injnameList = read_frame(filename, ifo, readstrain, strain_chan, dq_chan, inj_chan)
    else:
        strain, gpsStart, ts, qmask, shortnameList, injmask, injnameList = read_hdf5(filename, readstrain)
        
    #-- Create the time vector
    gpsEnd = gpsStart + len(qmask)
    if tvec:
        time = np.arange(gpsStart, gpsEnd, ts)
    else:
        meta = {}
        meta['start'] = gpsStart
        meta['stop']  = gpsEnd
        meta['dt']    = ts

    #-- Create 1 Hz DQ channel for each DQ and INJ channel
    channel_dict = {}  #-- 1 Hz, mask
    slice_dict   = {}  #-- sampling freq. of stain, a list of slices
    final_one_hz = np.zeros(qmask.shape, dtype='int32')
    for flag in shortnameList:
        bit = shortnameList.index(flag)
        # Special check for python 3
        if isinstance(flag, bytes): flag = flag.decode("utf-8") 
        
        channel_dict[flag] = (qmask >> bit) & 1

    for flag in injnameList:
        bit = injnameList.index(flag)
        # Special check for python 3
        if isinstance(flag, bytes): flag = flag.decode("utf-8") 
        
        channel_dict[flag] = (injmask >> bit) & 1
       
    #-- Calculate the DEFAULT channel
    try:
        channel_dict['DEFAULT'] = ( channel_dict['DATA'] )
    except:
        print("Warning: Failed to calculate DEFAULT data quality channel")

    if tvec:
        return strain, time, channel_dict
    else:
        return strain, meta, channel_dict



 # function to whiten data



def whiten(strain, interp_psd, dt):
    Nt = len(strain)
    freqs = np.fft.rfftfreq(Nt, dt)
    # whitening: transform to freq domain, divide by asd, then transform back, 
    # taking care to get normalization right.
    hf = np.fft.rfft(strain)
    white_hf = hf / (np.sqrt(interp_psd(freqs) /dt/2.))
    white_ht = np.fft.irfft(white_hf, n=Nt)
    return white_ht

def calcWhitenedStrain(strain_H1, strain_L1, time, fs, fband):
    # the time sample interval (uniformly sampled!)
    dt = time[1] - time[0]

    # number of sample for the fast fourier transform:
    fs=int(fs)
    NFFT = 4*fs
    f_min = 10
    f_max = 2000
    Pxx_H1, freqs = mlab.psd(strain_H1, Fs = fs, NFFT = NFFT)     ##### psd of the strain
    Pxx_L1, freqs = mlab.psd(strain_L1, Fs = fs, NFFT = NFFT)     #####
    #print("Pxx_H1: ", Pxx_H1)
    #print("Pxx_L1: ", Pxx_L1)
    #print("freqs: ", freqs)

    # We will use interpolations of the ASDs computed above for whitening:
    psd_H1 = interp1d(freqs, Pxx_H1)
    psd_L1 = interp1d(freqs, Pxx_L1)
    #print("psd_H1: ", psd_H1)
    #print("psd_L1: ", psd_L1)

    # now whiten the data from H1 and L1, and also the NR template:
    strain_H1_whiten = whiten(strain_H1,psd_H1,dt)
    strain_L1_whiten = whiten(strain_L1,psd_L1,dt)
    #print("strain_H1_whiten: ", strain_H1_whiten)
    #print("strain_L1_whiten: ", strain_L1_whiten)

    # We need to suppress the high frequencies with some bandpassing:
    bb, ab = butter(4, [fband[0]*2./fs, fband[1]*2./fs], btype='band')
    normalization = np.sqrt((fband[1]-fband[0])/(fs/2))
    strain_H1_whitenbp = filtfilt(bb, ab, strain_H1_whiten) / normalization
    strain_L1_whitenbp = filtfilt(bb, ab, strain_L1_whiten) / normalization
    # print("bb: ", bb)
    # print("ab: ", ab)
    # print("normalization: ", normalization)
    # print("strain_H1_whitenbp: ", strain_H1_whitenbp)
    # print("strain_L1_whitenbp: ", strain_L1_whitenbp)
    # print("time: ", time)

    return strain_H1_whitenbp, strain_L1_whitenbp, time

def formatHDF5File(H1FileName, L1FileName):    
    strain_H1, time, chan_dict_H1 = loaddata(H1FileName, 'H1')
    strain_L1, time, chan_dict_L1 = loaddata(L1FileName, 'L1')
    tstart = time[0]
    tend = time[-1]+0.0002441 #the addition of the last time segment is to round the last number up to the next second to make the math nice.
    tduration = tend-tstart
    fs = round(len(time) / tduration)
    #We are hard coding fband here to [43,800] at prof gebhart's recommendation, this should encompass most of the data. 
    #I would like to be able to calculate this manually for each data file but I am not in a position right now where that is feasible
    fband = [43,800]
    return strain_H1, strain_L1, time, fs, fband

def loadTXTFile(txtFileName):
    H1FileNames = []
    L1FileNames = []
    try:
        txtFileData = np.loadtxt(""+txtFileName+"", dtype=str)
        H1FileNames = txtFileData[0::2]
        L1FileNames = txtFileData[1::2]
        print(H1FileNames)
        print(L1FileNames)
    except:
        print("Text file either is not found or has no entries in it. Please make sure that the file has ordered pairs of H1 and L1 HDF5 files.")
        quit()
    if len(H1FileNames)!=len(L1FileNames): #makes sure that there are correctly formed file pairs hopefully
        print("Please make sure that there are an equal number of H1 and L1 HDF5 files and that they are organized properly.")
        quit()
    TeventNumbers = []
    index=0
    while index<len(H1FileNames):
        TeventNumbers.append(int(H1FileNames[index].split("-")[-2])+16.44)
        print(TeventNumbers[index])
        print("________")
        index+=1
    return H1FileNames, L1FileNames, TeventNumbers

#time to actually run the code and plot the graphs
H1FileNames = []
L1FileNames = []
TeventNumbers = []
txtFileName = 'STDGravWaveFiles.txt'
H1FileNames, L1FileNames, TeventNumbers = loadTXTFile(txtFileName)
strain_H1 = []
strain_L1 = []
time = []
fs = []
fband = []
index = 0 #location tracker as iterating through file list

while index<len(H1FileNames):
    SH1 = []
    SL1 = [] #gotta manually remake all the vars so they get attributed, then append them manually to make sure they get saved and added as lists correctly
    ttemp = 0
    fstemp = 0
    fbandtemp = []
    SH1, SL1, ttemp, fstemp, fbandtemp = formatHDF5File(H1FileNames[index], L1FileNames[index])
    strain_H1.append(SH1)
    strain_L1.append(SL1)
    time.append(ttemp)
    fs.append(fstemp)
    fband.append(fbandtemp)
    index+=1
strain_H1_whitened = []
strain_L1_whitened = []
index=0

while index<len(H1FileNames):
    tempWhiteStrainH1 = []
    tempWhiteStrainL1 = []
    t = 0
    print(strain_H1)
    print(strain_H1[index])
    tempWhiteStrainH1, tempWhiteStrainL1, t = calcWhitenedStrain(strain_H1[index], strain_L1[index], time[index], fs[index], fband[index])
    strain_H1_whitened.append(tempWhiteStrainH1)
    strain_L1_whitened.append(tempWhiteStrainL1)
    index+=1

plt.subplot(2,1,1)
index = 0
H1EDL = []
L1EDL = []
PositiveTimeRange = 8*10/12.0
NegativeTimeRange = -10

while index<len(H1FileNames):
    plt.plot(np.array(time[index])-TeventNumbers[index], strain_H1_whitened[index], label="" + getGWName(TeventNumbers[index]) + " -- H1 whitened h(t)", lw=1.5, alpha=0.8)
    plt.plot(np.array(time[index])-TeventNumbers[index], strain_L1_whitened[index], label="" + getGWName(TeventNumbers[index]) + " -- L1 whitened h(t)", lw=1.5, alpha=0.8)
    #print("H1 graph data: ", strain_H1_whitened[index])
    #print("L1 graph data: ", strain_L1_whitened[index])
    plt.legend(loc='upper left')
    #print("normal graph data time: ", np.array(time[index])-TeventNumbers[index])
    #print("time value for testing2: ", time[index])
    #print("time valye for testing3: ", TeventNumbers[index])
    H1EDL.append(np.array(strain_H1_whitened[index])[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]])
    L1EDL.append(np.array(strain_L1_whitened[index])[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]])
    # print("H1EDL append 1: ", np.array(strain_H1_whitened[index])[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]])
    # print("L1EDL append 1: ", np.array(strain_L1_whitened[index])[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]])
    index+=1
plt.ylim([-10,10])
plt.xlim([-1,1])
plt.grid()
plt.subplot(2,1,2)
plt.grid()
index=0
n = 100 #this decides how many parts to split it into
chunk = len(H1EDL[0])//n
#print("chunk", chunk)
print((chunk))

while index<len(H1FileNames):
    STDData = []
    STDDataTime = []
    H1minL1EDL = []
    index2=0
    H1minL1EDL.append(H1EDL[index]-L1EDL[index])
    #print("H1minL1EDL: " + str(H1minL1EDL[0:5]))
    # print("H1minL1EDL total values and stuff: ", H1minL1EDL[0])
    # print("H1EDL 2: ", H1EDL[0])
    # print("L1EDL 2: ", L1EDL[0])
    #print("H1Strain 3: ", strain_H1_whitened[0])
    #print("L1Strain 3: ", strain_L1_whitened[0])
    minusTime = np.array(time[index]-TeventNumbers[index])[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]]  #||||||||||||||||
    #print("\nminusTime: ", minusTime)

    for i in range(n):  #i is the time segment start time for the current segment of data being analyzed i think
        data_E1 = np.array([])
        data_E1 = np.append(data_E1, H1minL1EDL[0][i*(chunk):(i+1)*(chunk)])
        # if i==50:
        #     print("data_E1 3: ", data_E1[0:10])
        #print("data_e1 append: ", H1minL1EDL[0][i*(chunk):(i+1)*(chunk)])
        STDData.append(np.std(data_E1))
        # if i==50:
        #     print("STD data_e1 4: ", np.std(data_E1))
        #print("data e1 vals: ", data_E1[0])
        #print("stddata e1 apend: ", np.std(data_E1))
        #print("|||||||||||||||||||||||", np.std(data_E1))
        new_t = np.array((minusTime))#[np.where([(NegativeTimeRange < np.array(time[index])-TeventNumbers[index]) & (np.array(time[index])-TeventNumbers[index] < PositiveTimeRange)])[1]]  #||||||||||||||||
        STDDataTime.append(np.average(new_t[i*(chunk):(i+1)*(chunk)]))
        #print("std data time append: ", np.average(new_t[i*(chunk):(i+1)*(chunk)]))
    #print(np.array(STDDataTime)-TeventNumbers[index], STDData)
    plt.plot(np.array(STDDataTime), STDData, label="STD H1-L1 for " + getGWName(TeventNumbers[index]), lw=2, alpha=1)
    #print("datamidpoint: "+str(STDData[int(len(STDData)/2)]))
    plt.legend(loc='upper left')
    # print("STDData_E1: 5", STDData)
    #print("plotting "+getGWName(TeventNumbers[index])+"!!!!!")
    # print("STDDataTime_E1: 6", np.array(STDDataTime))
    index+=1

#plt.plot(range(-100,100), [0]*200, 'k-')
#plt.ylim([-.1,3])
plt.xlim([-10.0,10.0])
plt.legend(loc='upper left')
plt.show()




#4 seconds 10,100






















